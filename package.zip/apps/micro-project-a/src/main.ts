import './assets/main.css'

import { createPinia } from 'pinia'
import { createApp, } from 'vue'
import type { App as AppInstance } from 'vue'
import { createRouter, createWebHistory, } from 'vue-router'
import { routes } from './router'

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/reset.css'
import "./public-path";

import App from './App.vue'

let app = null
let router = null
let history = null

function handleMicroData() {
    console.log('child-vite getData:', window.microApp?.getData())

    // 监听基座下发的数据变化
    window.microApp?.addDataListener((data) => {
        console.log('child-vite addDataListener:', data)
    }, true)

    // 向基座发送数据
    setTimeout(() => {
        window.microApp?.dispatch({ myname: 'child-vite' })
    }, 3000)
}


// 将渲染操作放入 mount 函数
window.mount = (data) => {

    console.group('子应用 mount');
    console.log('__MICRO_APP_BASE_ROUTE__ :>> ', window.__MICRO_APP_BASE_ROUTE__);
    console.log('应用名称 :>> ', window.__MICRO_APP_NAME__);
    console.log('子应用的静态资源前缀 :>> ', window.__MICRO_APP_PUBLIC_PATH__);
    console.log('是否是主应用 :>> ', window.__MICRO_APP_BASE_APPLICATION__);

    console.log('微应用vite渲染了 -- UMD模式', data);

    console.groupEnd();

    history = createWebHistory(window.__MICRO_APP_BASE_ROUTE__ || import.meta.env.BASE_URL)
    router = createRouter({
        history,
        routes,
    })

    app = createApp(App)
    app.use(router)
    app.use(ElementPlus)
    app.use(Antd)
    app.mount('#vite-app')


    handleMicroData()
}

// 将卸载操作放入 unmount 函数
window.unmount = () => {
    app && app.unmount()
    history && history.destroy()
    app = null
    router = null
    history = null
    console.log('微应用vite卸载了 -- UMD模式');
}

// 非微前端环境直接渲染
if (!window.__MICRO_APP_ENVIRONMENT__) {
    mount()
}